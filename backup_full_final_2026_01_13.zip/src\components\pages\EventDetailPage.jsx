import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import SocialSidebar from '../layout/SocialSidebar';
import { eventsData } from '../../data/events';

const EventDetailPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [event, setEvent] = useState(null);

    useEffect(() => {
        // Find event by ID
        const foundEvent = eventsData.find(e => e.id === parseInt(id));
        if (foundEvent) {
            setEvent(foundEvent);
            window.scrollTo(0, 0);
        } else {
            // Redirect if not found
            navigate('/');
        }
    }, [id, navigate]);

    if (!event) return null;

    // Helpers
    const formatDate = (isoString) => {
        if (!isoString) return '';
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        // Create date with time to ensure correct day
        return new Date(isoString).toLocaleDateString('es-ES', options);
    };

    const getYear = (isoString) => new Date(isoString).getFullYear();

    const renderMiniCalendar = (evt) => {
        if (!evt) return null;

        const startDate = new Date(evt.date);
        const endDate = evt.endDate ? new Date(evt.endDate) : startDate;

        const year = startDate.getFullYear();
        const month = startDate.getMonth(); // 0-indexed

        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const firstDayOffset = new Date(year, month, 1).getDay(); // 0 (Sun) - 6 (Sat)

        const days = [];
        for (let i = 0; i < firstDayOffset; i++) {
            days.push(<div key={`empty-${i}`} className="h-8 w-8"></div>);
        }

        for (let d = 1; d <= daysInMonth; d++) {
            const currentDate = new Date(year, month, d);
            // Ignore time for comparison
            const isSelected = d === startDate.getDate() && month === startDate.getMonth();
            const isInRange = endDate && currentDate >= startDate && currentDate <= endDate;

            days.push(
                <div
                    key={d}
                    className={`h-8 w-8 flex items-center justify-center rounded-full text-sm font-bold transition-all
                    ${isSelected ? 'bg-iskf-red text-white shadow-[0_0_15px_#be1322] scale-110' : isInRange ? 'bg-iskf-red/40 text-white' : 'text-gray-500 hover:text-white'}
                    `}
                >
                    {d}
                </div>
            );
        }

        return (
            <div className="bg-black/40 backdrop-blur-md p-6 rounded-2xl border border-white/10 w-full max-w-sm hover:border-iskf-red/30 transition-colors duration-500">
                <div className="text-center mb-4 flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="font-black text-white uppercase text-lg tracking-widest">{startDate.toLocaleString('es-ES', { month: 'long' })}</span>
                    <span className="text-iskf-red font-bold">{year}</span>
                </div>
                <div className="grid grid-cols-7 gap-2">
                    {['D', 'L', 'K', 'M', 'J', 'V', 'S'].map(d => (
                        <div key={d} className="text-center text-xs text-iskf-red font-black mb-2">{d}</div>
                    ))}
                    {days}
                </div>
            </div>
        );
    };

    return (
        <div className="bg-iskf-dark min-h-screen text-white font-sans selection:bg-iskf-red selection:text-white">
            {/* Floating Back Button */}
            <motion.button
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                onClick={() => navigate('/', { state: { targetId: 'eventos' } })}
                className="fixed top-24 left-6 md:left-16 z-50 w-12 h-12 bg-black/50 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-white hover:bg-iskf-red hover:border-iskf-red transition-all duration-300 shadow-lg group"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
            </motion.button>

            <SocialSidebar />

            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="min-h-screen w-full relative"
            >
                {/* Background Art (Subtle underlying) */}
                <div className="absolute inset-0 z-0 select-none pointer-events-none fixed">
                    <img src={`/${event.logo}`} className="w-full h-full object-cover blur-3xl opacity-10 scale-150" alt="bg blur" onError={(e) => e.target.src = '/iskfLogo.png'} />
                    <div className="absolute inset-0 bg-iskf-dark/90"></div>
                </div>

                <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="relative z-10 w-full min-h-screen flex flex-col md:flex-row"
                >
                    {/* LEFT COLUMN: Visuals (Fixed Sticky on Desktop) */}
                    <div className="w-full md:w-5/12 bg-black relative flex items-center justify-center p-12 overflow-hidden min-h-[40vh] md:h-screen md:sticky md:top-0">
                        {/* Background Effect */}
                        <div className="absolute inset-0 opacity-40">
                            <img src={`/${event.logo}`} className="w-full h-full object-cover blur-sm opacity-50" alt="bg" onError={(e) => e.target.src = '/iskfLogo.png'} />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent md:bg-gradient-to-r"></div>

                        {/* Main Logo */}
                        <motion.img
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ delay: 0.4, type: "spring" }}
                            src={`/${event.logo}`}
                            alt={event.name}
                            className="relative z-10 w-64 h-64 object-contain drop-shadow-[0_0_30px_rgba(255,255,255,0.15)]"
                            onError={(e) => e.target.src = '/iskfLogo.png'}
                        />
                    </div>

                    {/* RIGHT COLUMN: Details (Scrollable) */}
                    <div className="w-full md:w-7/12 p-8 md:p-16 md:pt-32 flex flex-col bg-iskf-dark/50 backdrop-blur-sm">
                        {/* Header Badge */}
                        <div className="flex items-center space-x-4 mb-6">
                            <span className="text-iskf-red font-black text-lg tracking-widest uppercase">{getYear(event.date)}</span>
                            <div className="h-6 w-[1px] bg-white/20"></div>
                            <span className={`text-sm font-bold uppercase px-3 py-1 rounded bg-white/5 tracking-wider ${event.type === 'Internacional' ? 'text-blue-400' : 'text-green-400'}`}>
                                {event.type}
                            </span>
                        </div>

                        {/* Title */}
                        <h1 className="text-4xl md:text-6xl font-black text-white mb-8 uppercase leading-none tracking-tight">
                            {event.name}
                        </h1>

                        {/* Info Block */}
                        <div className="space-y-10 flex-grow">
                            <div className="flex items-start space-x-6">
                                {renderMiniCalendar(event)}
                                <div className="pt-1">
                                    <h4 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-2">Fecha del Evento</h4>
                                    <p className="text-white font-medium text-xl md:text-2xl">
                                        {formatDate(event.date)}
                                        {event.endDate && <span className="block mt-1 text-gray-400 text-lg">hasta {formatDate(event.endDate)}</span>}
                                    </p>
                                </div>
                            </div>

                            <div className="flex items-start space-x-6">
                                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center flex-shrink-0 text-iskf-red border border-white/5">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                </div>
                                <div className="pt-1">
                                    <h4 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-2">Ubicación</h4>
                                    <p className="text-white font-medium text-xl flex items-center">
                                        {event.location}
                                        <img src={`/${event.flag}`} className="w-6 h-6 ml-3 rounded-full shadow-sm" alt="flag" />
                                    </p>
                                </div>
                            </div>

                            <div className="bg-white/5 p-8 rounded-3xl border border-white/5 mt-6">
                                <h4 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-3">Descripción</h4>
                                <p className="text-gray-300 leading-relaxed text-base md:text-lg">
                                    {event.description}
                                </p>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col sm:flex-row gap-4 mt-12 pt-8 border-t border-white/10">
                            <button
                                className="flex-1 py-4 bg-blue-600 text-white uppercase font-black tracking-[0.2em] rounded-xl hover:bg-blue-500 transition-all hover:scale-[1.02] shadow-lg flex items-center justify-center gap-3 group"
                                onClick={() => {
                                    const startTime = new Date(event.date).toISOString().replace(/-|:|\.\d\d\d/g, "");
                                    const endTime = event.endDate
                                        ? new Date(event.endDate).toISOString().replace(/-|:|\.\d\d\d/g, "")
                                        : new Date(new Date(event.date).getTime() + 2 * 60 * 60 * 1000).toISOString().replace(/-|:|\.\d\d\d/g, "");

                                    const details = encodeURIComponent(event.description);
                                    const location = encodeURIComponent(event.location);
                                    const text = encodeURIComponent(event.name);

                                    const url = `https://www.google.com/calendar/render?action=TEMPLATE&text=${text}&dates=${startTime}/${endTime}&details=${details}&location=${location}`;
                                    window.open(url, '_blank');
                                }}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 group-hover:-translate-y-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                Agendar en mi Calendario
                            </button>

                        </div>
                    </div>
                </motion.div>
            </motion.div>
        </div>
    );
};

export default EventDetailPage;
