import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const OrbitalTimeline = ({ dojos }) => {
    const [expandedId, setExpandedId] = useState(null);
    const [rotation, setRotation] = useState(0);
    const requestRef = useRef();
    const startTimeRef = useRef();
    const containerRef = useRef();

    // Configuration
    const RADIUS_X = 280;
    const RADIUS_Y = 80; // Flatter for atomic look
    const SPEED = 0.005; // Much slower
    const ORBITS = [0, 60, 120]; // Degrees of rotation for the 3 atomic rings

    // Animation Loop
    const animate = (time) => {
        if (!startTimeRef.current) startTimeRef.current = time;
        setRotation(prev => (prev + SPEED) % (Math.PI * 2)); // Use Radians for easier math
        requestRef.current = requestAnimationFrame(animate);
    };

    useEffect(() => {
        requestRef.current = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(requestRef.current);
    }, []);

    return (
        <div
            ref={containerRef}
            className="relative w-full h-full min-h-[500px] flex items-center justify-center overflow-visible perspective-1000"
        >
            {/* Sun Center (ISKF) - Gyroscope Core */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 flex items-center justify-center group cursor-pointer">

                {/* Core Glow - Enhanced Radiation */}
                <div className="absolute w-32 h-32 bg-iskf-red/40 rounded-full blur-[40px] animate-pulse group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute w-20 h-20 bg-blue-500/20 rounded-full blur-[20px] animate-pulse delay-75"></div>

                {/* ELECTRIC SPARKS (CORE LIGHTNING) */}
                <svg className="absolute inset-[-100%] w-[300%] h-[300%] pointer-events-none z-30 overflow-visible" viewBox="0 0 100 100">
                    <defs>
                        <filter id="bolt-glow" x="-50%" y="-50%" width="200%" height="200%">
                            <feGaussianBlur stdDeviation="0.5" result="blur" />
                            <feMerge>
                                <feMergeNode in="blur" />
                                <feMergeNode in="SourceGraphic" />
                            </feMerge>
                        </filter>
                    </defs>
                    {/* Lightning Bolts - Chaotic Flashes */}
                    {[
                        "M50 50 L55 35 L48 30 L60 10", // Up
                        "M50 50 L40 45 L35 55 L10 50", // Left
                        "M50 50 L60 65 L55 75 L80 90", // Down Right
                        "M50 50 L35 35 L40 25 L20 20"  // Top Left
                    ].map((d, i) => (
                        <motion.path
                            key={i}
                            d={d}
                            stroke="white"
                            strokeWidth="0.2"
                            fill="none"
                            filter="url(#bolt-glow)"
                            initial={{ opacity: 0, pathLength: 0 }}
                            animate={{
                                opacity: [0, 0.8, 0, 0, 0.6, 0], // Flash pattern
                                pathLength: [0, 1, 1],
                                strokeWidth: [0.1, 0.8, 0.1]
                            }}
                            transition={{
                                duration: 0.2 + Math.random() * 0.5,
                                repeat: Infinity,
                                repeatType: "mirror",
                                repeatDelay: Math.random() * 2, // Random pauses
                                ease: "linear"
                            }}
                        />
                    ))}
                    {/* Halo Flash */}
                    <motion.circle
                        cx="50" cy="50" r="15"
                        stroke="#BE1322" strokeWidth="1" fill="none"
                        initial={{ r: 15, opacity: 0.5 }}
                        animate={{ r: [15, 25], opacity: [0.5, 0] }}
                        transition={{ duration: 1, repeat: Infinity }}
                    />
                </svg>

                {/* The Core Sphere - Image Based */}
                <div className="relative w-24 h-24 rounded-full shadow-[0_0_60px_rgba(190,19,34,0.6)] flex items-center justify-center z-10 overflow-hidden border border-white/30 group-hover:scale-105 transition-transform duration-500 group-hover:shadow-[0_0_80px_rgba(190,19,34,0.9)]">

                    {/* Background Image */}
                    <div className="absolute inset-0 bg-black">
                        <img src="/iskfFondoRojo.jpg" alt="ISKF Core" className="w-full h-full object-cover opacity-90 hover:opacity-100 transition-opacity duration-500" />
                    </div>

                    {/* Sphere Depth Overlay (Inner Shadow) */}
                    <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/80"></div>

                    {/* Glassy Gloss Reflection */}
                    <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/40 to-transparent opacity-60 rounded-t-full"></div>

                    {/* Subtle Scanline/Tech Texture */}
                    <div className="absolute inset-0 bg-[url('/noise.png')] opacity-20 mix-blend-overlay"></div>
                </div>

                {/* Gyroscope Ring 1 (Slow Horizontal) */}
                <div className="absolute w-36 h-36 rounded-full border border-white/20 border-t-iskf-red border-b-transparent animate-[spin_6s_linear_infinite] pointer-events-none mix-blend-screen shadow-[0_0_15px_rgba(190,19,34,0.4)]"></div>

                {/* Gyroscope Ring 2 (Fast Vertical-ish) */}
                <div className="absolute w-44 h-44 rounded-full border-[1px] border-white/10 border-l-white/60 border-r-transparent animate-[spin_4s_linear_infinite_reverse] pointer-events-none" style={{ transform: 'rotateX(60deg) rotateY(15deg)' }}></div>

                {/* Gyroscope Ring 3 (Tilted) */}
                <div className="absolute w-52 h-52 rounded-full border-[1px] border-iskf-red/30 border-r-iskf-red animate-[spin_9s_linear_infinite]" style={{ transform: 'rotateX(75deg) rotateY(-15deg)' }}></div>

                {/* Central Electric Discharge */}
                <div className="absolute w-60 h-60 border border-dotted border-white/10 rounded-full animate-[spin_20s_linear_infinite] opacity-30"></div>

            </div>

            {/* ATOMIC RINGS BACKGROUND - RESONANCE */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
                <defs>
                    <filter id="glow-resonance" x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                        <feMerge>
                            <feMergeNode in="coloredBlur" />
                            <feMergeNode in="SourceGraphic" />
                        </feMerge>
                    </filter>
                    <linearGradient id="orbit-energy" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="transparent" />
                        <stop offset="50%" stopColor="#BE1322" />
                        <stop offset="100%" stopColor="transparent" />
                    </linearGradient>
                </defs>
                {ORBITS.map((deg, i) => (
                    <g key={i} style={{ transformOrigin: 'center', transform: `rotate(${deg}deg)` }}>
                        {/* RADIOACTIVE SHADOW PIVOT (New Layer) */}
                        <motion.ellipse
                            cx="50%" cy="50%"
                            rx={RADIUS_X} ry={RADIUS_Y}
                            fill="none"
                            stroke="#BE1322"
                            initial={{ opacity: 0, rx: RADIUS_X, ry: RADIUS_Y }}
                            animate={{
                                opacity: [0.2, 0.6, 0.2],
                                strokeWidth: [4, 12, 4], // Expanding radioactive pulse
                                rx: [RADIUS_X, RADIUS_X + 10, RADIUS_X], // Breathing shape
                            }}
                            transition={{
                                duration: 4,
                                repeat: Infinity,
                                ease: "easeInOut",
                                delay: i * 0.7 // Staggered pulsing
                            }}
                            className="blur-md mix-blend-screen"
                        />

                        {/* Resonance Glow (Outer) - ALIVE */}
                        <ellipse
                            cx="50%" cy="50%"
                            rx={RADIUS_X} ry={RADIUS_Y}
                            fill="none"
                            stroke="rgba(190, 19, 34, 0.4)"
                            strokeWidth="2"
                            filter="url(#glow-resonance)"
                            className="opacity-40 animate-pulse"
                            style={{ animationDuration: `${2 + i}s` }}
                        />
                        {/* Energy Flow Line (Static Dashed for now to prevent wobble) */}
                        <ellipse
                            cx="50%" cy="50%"
                            rx={RADIUS_X} ry={RADIUS_Y}
                            fill="none"
                            stroke="rgba(255,255,255,0.4)"
                            strokeWidth="1"
                            strokeDasharray="10 20"
                            className="opacity-50"
                        />
                        {/* Core Line (Inner Thread) */}
                        <ellipse
                            cx="50%" cy="50%"
                            rx={RADIUS_X} ry={RADIUS_Y}
                            fill="none"
                            stroke="rgba(255,255,255,0.2)"
                            strokeWidth="0.5"
                        />
                    </g>
                ))}
            </svg>

            {/* Nodes */}
            {dojos.map((dojo, index) => {
                const total = dojos.length;
                const orbitIndex = index % 3; // 0, 1, 2
                const orbitAngleDeg = ORBITS[orbitIndex];
                const orbitAngleRad = orbitAngleDeg * (Math.PI / 180);

                // Distribute evenly along the logical time, but mapped to separate orbits
                const angleOffset = (index / total) * 2 * Math.PI; // Keep timeline logic
                const currentAngle = rotation + angleOffset;

                // 1. Calculate Local position on horizontal oval
                const localX = RADIUS_X * Math.cos(currentAngle);
                const localY = RADIUS_Y * Math.sin(currentAngle);

                // 2. Rotate by Orbit Angle (2D rotation matrix)
                const x = localX * Math.cos(orbitAngleRad) - localY * Math.sin(orbitAngleRad);
                const y = localX * Math.sin(orbitAngleRad) + localY * Math.cos(orbitAngleRad);

                // 3D Depth calculations
                const depth = Math.sin(currentAngle);

                const scale = 0.5 + 0.5 * ((1 + depth) / 2); // 0.5 to 1.0
                const opacity = 0.4 + 0.6 * ((1 + depth) / 2); // 0.4 to 1.0
                const zIndex = Math.round(100 + 50 * depth);

                const isExpanded = expandedId === dojo.id;

                return (
                    <motion.div
                        key={dojo.id}
                        className="absolute top-1/2 left-1/2 cursor-pointer" // Standard absolute positioning
                        style={{
                            x: isExpanded ? 0 : x,
                            y: isExpanded ? 0 : y,
                            xPercent: -50, // PERFECT CENTERING: Offset by 50% of own width
                            yPercent: -50, // PERFECT CENTERING: Offset by 50% of own height
                            zIndex: isExpanded ? 200 : zIndex,
                            scale: isExpanded ? 1 : scale,
                            opacity: isExpanded ? 1 : opacity,
                        }}
                        transition={isExpanded ? { type: 'spring', stiffness: 200, damping: 20 } : { duration: 0 }}
                        onClick={() => setExpandedId(isExpanded ? null : dojo.id)}
                    >
                        {/* Node Content */}
                        <div
                            className={`relative w-12 h-12 md:w-16 md:h-16 bg-black border ${isExpanded ? 'border-iskf-red bg-white' : 'border-white/30'} rounded-full flex items-center justify-center shadow-[0_0_15px_rgba(0,0,0,0.5)] transition-all duration-300 group hover:border-iskf-red hover:shadow-[0_0_20px_#ce1126] hover:scale-110`}
                        >
                            <img src={`/${dojo.logo}`} alt={dojo.name} className="w-[70%] h-[70%] object-contain" />

                            {/* Label */}
                            {!isExpanded && opacity > 0.8 && (
                                <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 text-[9px] md:text-[10px] font-black uppercase tracking-wider text-white whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-md bg-black/50 px-2 py-1 rounded backdrop-blur-sm pointer-events-none">
                                    {dojo.name}
                                </div>
                            )}
                        </div>

                        {/* Expanded Card */}
                        <AnimatePresence>
                            {isExpanded && (
                                <motion.div
                                    className="fixed inset-0 z-[500] flex items-center justify-center p-4 pointer-events-none"
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    onClick={(e) => { e.stopPropagation(); setExpandedId(null); }}
                                >
                                    {/* Backdrop for card */}
                                    <div className="absolute inset-0 bg-black/80 backdrop-blur-md pointer-events-auto"></div>

                                    <motion.div
                                        layoutId={`card-${dojo.id}-content`}
                                        className="relative bg-zinc-900/90 border border-white/10 rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-[0_0_50px_rgba(190,19,34,0.3)] pointer-events-auto text-center backdrop-blur-xl"
                                        initial={{ scale: 0.8, y: 50, opacity: 0 }}
                                        animate={{ scale: 1, y: 0, opacity: 1 }}
                                        exit={{ scale: 0.8, opacity: 0 }}
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        <button className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors" onClick={() => setExpandedId(null)}>
                                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                        </button>
                                        <div className="w-24 h-24 bg-white rounded-2xl mx-auto mb-6 p-4 shadow-inner flex items-center justify-center relative overflow-hidden">
                                            <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-white"></div>
                                            <img src={`/${dojo.logo}`} alt={dojo.name} className="w-full h-full object-contain relative z-10" />
                                        </div>
                                        <span className="inline-block px-3 py-1 rounded-full bg-iskf-red/10 text-iskf-red text-[10px] font-black uppercase tracking-widest mb-4 border border-iskf-red/20">{dojo.province}</span>
                                        <h3 className="text-2xl font-black text-white uppercase mb-2 leading-none">{dojo.name}</h3>
                                        <div className="w-12 h-1 bg-iskf-red mx-auto mb-6 rounded-full"></div>

                                        <div className="space-y-4 text-left bg-black/20 p-6 rounded-2xl border border-white/5">
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 rounded-full bg-iskf-red/10 flex items-center justify-center text-iskf-red text-xl">🥋</div>
                                                <div>
                                                    <span className="block text-[10px] uppercase text-gray-500 font-bold tracking-wider">Sensei</span>
                                                    <span className="text-lg font-bold text-gray-200">{dojo.sensei}</span>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 text-xl">📍</div>
                                                <div>
                                                    <span className="block text-[10px] uppercase text-gray-500 font-bold tracking-wider">Ubicación</span>
                                                    <span className="text-sm font-medium text-gray-300 hover:text-blue-400 cursor-pointer transition-colors">Ver en Google Maps</span>
                                                </div>
                                            </div>
                                        </div>

                                        <button className="mt-8 w-full py-4 bg-white text-black font-black uppercase tracking-widest rounded-xl hover:bg-iskf-red hover:text-white transition-all duration-300 shadow-xl group">
                                            Contactar Dojo <span className="inline-block transition-transform group-hover:translate-x-1">→</span>
                                        </button>
                                    </motion.div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </motion.div>
                );
            })}
        </div>
    );
};

export default OrbitalTimeline;
